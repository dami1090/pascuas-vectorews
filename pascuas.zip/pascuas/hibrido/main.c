#include <stdio.h>
#include <stdlib.h>
#define CANT 5
int main()
{
    int estado[CANT];

    printf("Hello world!\n");
    return 0;
}
