#include <stdio.h>
#define CANT 5
void main(void)
{
    int v[CANT],i;
    float sueldo[CANT];
    int legajo[CANT];
    for (i=0; i<CANT; i++)
    {
        legajo[i]=i+1;
        printf("\n Ingrese edad a cargar en el vector: ");
        scanf("%d",&v[i]);
        printf("\n Ingrese sueldo: ");
        scanf("%f",&sueldo[i]);
    }
    for (i=0; i<CANT; i++)
    {
        printf("\n legajo empelado Numero:%d de edad:%d cobra:%f",legajo[i],v[i],sueldo[i]);
    }
}
