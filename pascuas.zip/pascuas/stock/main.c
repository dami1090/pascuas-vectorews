#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#define CANT 5
int main()
{
    int v[CANT],i,pos;
    char seguir;
    float sueldo[CANT];
    int legajo[CANT];
    for(i=0; i<CANT; i++)
    {
        v[i]=0;
    }
    do
    {
        printf("Ingrese posici�n");
        scanf("%d",&pos);
        printf("Ingrese valor a cargar en el vector");
        scanf("%d",&v[pos]);
        printf("Desea ingresar otro dato S/N?");
        seguir=fflush(stdin);
        scanf("%c",&seguir);
    }
    while(seguir=='s');
    {
        for(i=0;i<CANT;i++)
        {
            printf("\n mostrar:%d",v[i]);
        }
    }
    return 0;
}
